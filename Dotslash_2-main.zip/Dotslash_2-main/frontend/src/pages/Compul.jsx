import Layout from "./Layout";

import Footer from "./Footer";

export default function Compul(){

    return(
        <>
        <Layout/>
        <Footer/>
        </>
    )
}